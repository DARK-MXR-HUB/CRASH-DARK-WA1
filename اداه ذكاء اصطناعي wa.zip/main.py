# language: Python 3.10+
# DEVELOPER: DARK MXR
import asyncio
import json
import os
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from neonize.aioze.client import NewAClient
from neonize.aioze.events import ConnectedEv, MessageEv, NewsletterJoinEv
from neonize.proto.Neonize_pb2 import NewsletterJID
from neonize.utils.jid import build_jid, JIDToNonAD
from neonize.utils.message import extract_text

# CONFIG keeps everything EXCEPT phone_number — that now comes from stdin
CONFIG = {
    "session_db": "wa_session.db",
    "data_db": "wa_data.db",
    "owner_channels": "https://whatsapp.com/channel/0029Vb9TO6G2ER6ju5pmgQ3Z",
    "ai_api_key": os.getenv("AI_API_KEY", "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"),
    "ai_model": "gpt-4o-mini",
    "ai_base_url": os.getenv("AI_BASE_URL", "https://api.openai.com/v1"),
    "persona": "You are a helpful, sharp assistant. Reply in the language the user writes in. Keep responses concise unless asked for detail.",
    "deleted_msg_chat": None,
}

# ─── CONSOLE INPUT ─────────────────────────────────────────────────────────
def prompt_phone_number() -> str:
    """Read phone number from console, validate, normalize."""
    print("=" * 48)
    print("  WhatsApp AI Persona Bot — Setup")
    print("=" * 48)
    print("Enter your phone number in international format.")
    print("  • Country code included, no +, no spaces, no leading 0")
    print("  • Example (Egypt):  201234567890")
    print("  • Example (Saudi):  966512345678")
    print("-" * 48)
    while True:
        raw = input("Phone number: ").strip()
        # strip common separators and leading +
        cleaned = re.sub(r"[\s\-\(\)\+]", "", raw)
        if not cleaned.isdigit():
            print("  ✗  digits only (after removing +, spaces, dashes)")
            continue
        if len(cleaned) < 10 or len(cleaned) > 15:
            print("  ✗  length must be 10–15 digits (country code + number)")
            continue
        print(f"  ✓  using: +{cleaned}")
        return cleaned

# ─── MAIN ──────────────────────────────────────────────────────────────────
async def main():
    phone = prompt_phone_number()
    owner_jid = f"{phone}@s.whatsapp.net"
    add_admin(owner_jid)
    print(f"[admin] seeded owner as admin: {owner_jid}\n")

    client = NewAClient(CONFIG["session_db"])

    @client.event(ConnectedEv)
    async def on_connected(c, _):
        print("[connected] session active")
        await auto_follow_owner_channels(c)

    @client.event(MessageEv)
    async def on_msg(c, ev):
        await on_message(c, ev)

    @client.event(NewsletterJoinEv)
    async def on_nl(c, ev):
        await on_newsletter_join(c, ev)

    needs_pairing = not Path(CONFIG["session_db"]).exists() or not client.is_logged_in
    if needs_pairing:
        print("[auth] requesting pairing code ...")
        code = await client.request_pairing_code(phone)
        print("\n" + "═" * 48)
        print(f"  PAIRING CODE:  {code}")
        print("═" * 48)
        print("On your phone:")
        print("  WhatsApp → Settings → Linked Devices")
        print("  → Link a Device → Link with phone number")
        print(f"  → enter: {code}")
        print("═" * 48 + "\n")

    await client.connect()
    await client.idle()

if __name__ == "__main__":
    asyncio.run(main())