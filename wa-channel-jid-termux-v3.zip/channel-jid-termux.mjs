import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers } from '@whiskeysockets/baileys'
import readline from 'node:readline'

const DEFAULT_CHANNEL_URL = 'https://whatsapp.com/channel/0029Vb9TO6G2ER6ju5pmgQ3Z'
const AUTH_DIR = './wa-auth'
const MAX_RECONNECTS = 6

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const ask = (prompt) => new Promise((resolve) => rl.question(prompt, resolve))

function extractInviteCode(input) {
  const value = input.trim()
  const pathMatch = value.match(/\/channel\/([A-Za-z0-9]+)/i)
  const code = pathMatch ? pathMatch[1] : value
  if (!/^[A-Za-z0-9]{10,64}$/.test(code)) {
    throw new Error('لم أتعرف على رمز الدعوة. ألصق رابطًا بصيغة https://whatsapp.com/channel/… أو الرمز نفسه.')
  }
  return code
}

function normalizePhone(input) {
  const digits = input.replace(/\D/g, '')
  if (digits.length < 8 || digits.length > 15) {
    throw new Error('أدخل رقم واتساب مع مفتاح الدولة، أرقام فقط، مثل 201012345678.')
  }
  return digits
}

async function main() {
  console.log('\nاستخراج معرّف قناة واتساب (JID) — لا يرسل رسائل.\n')
  const rawLink = await ask('رابط القناة [اضغط Enter لاستخدام قناة طمأنينة]:\n> ')
  const inviteCode = extractInviteCode(rawLink || DEFAULT_CHANNEL_URL)

  let sock
  let pairingRequested = false
  let lookupStarted = false
  let shuttingDown = false
  let reconnects = 0
  let phoneNumber

  const shutdown = async (exitCode = 0) => {
    if (shuttingDown) return
    shuttingDown = true
    rl.close()
    try { sock?.end(undefined) } catch {}
    setTimeout(() => process.exit(exitCode), 300)
  }

  const connect = async () => {
    if (shuttingDown || lookupStarted) return

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
    let saveQueue = Promise.resolve()
    sock = makeWASocket({
      auth: state,
      browser: Browsers.ubuntu('Chrome'),
      markOnlineOnConnect: false,
      syncFullHistory: false
    })

    sock.ev.on('creds.update', () => {
      saveQueue = saveQueue.then(() => saveCreds()).catch((error) => {
        console.error('تعذر حفظ بيانات الجلسة:', error.message)
      })
    })

    sock.ev.on('connection.update', async ({ connection, qr, lastDisconnect }) => {
      if (connection === 'connecting') console.log('جارٍ الاتصال بواتساب…')

      if (qr && !sock.authState.creds.registered && !pairingRequested) {
        pairingRequested = true
        try {
          if (!phoneNumber) {
            const phoneText = await ask('\nأدخل رقم واتساب مع مفتاح الدولة (أرقام فقط، دون +):\n> ')
            phoneNumber = normalizePhone(phoneText)
          }
          const code = await sock.requestPairingCode(phoneNumber)
          console.log(`\nرمز الاقتران: ${code}`)
          console.log('في واتساب: الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف.')
          console.log('أدخل الرمز هناك، ثم انتظر رسالة «تم الاتصال» هنا. لا تشارك الرمز.\n')
        } catch (error) {
          console.error(`تعذر طلب رمز الاقتران: ${error.message}`)
          await shutdown(1)
        }
      }

      if (connection === 'open' && !lookupStarted) {
        lookupStarted = true
        reconnects = 0
        console.log('تم الاتصال بواتساب. جارٍ جلب بيانات القناة…')
        try {
          const metadata = await sock.newsletterMetadata('invite', inviteCode)
          if (!metadata?.id) throw new Error('لم يُرجع واتساب معرّفًا للقناة. تحقق من رابط الدعوة.')
          console.log('\nالقناة:', metadata.name || '(لم يُرجع اسم القناة)')
          console.log('المعرّف:', metadata.id)
          console.log('\nانتهى الاستخراج. أُغلق اتصال السكربت. قد يظل الجهاز مرتبطًا؛ ألغِ الربط من الأجهزة المرتبطة إن رغبت.\n')
          await shutdown(0)
        } catch (error) {
          console.error(`\nفشل جلب بيانات القناة: ${error.message}`)
          console.error('تأكد من أن الرابط صحيح وأن القناة عامة، ثم جرّب مجددًا.\n')
          await shutdown(1)
        }
      }

      if (connection === 'close' && !shuttingDown && !lookupStarted) {
        const statusCode = lastDisconnect?.error?.output?.statusCode
        const reason = lastDisconnect?.error?.message || 'غير معروف'
        console.log(`انقطع الاتصال (رمز الحالة: ${statusCode ?? 'غير معروف'}؛ ${reason}).`)

        if (statusCode === DisconnectReason.loggedOut) {
          console.error('واتساب سجّل خروج الجهاز. احذف مجلد wa-auth ثم شغّل الأداة لبدء اقتران جديد.')
          await shutdown(1)
          return
        }

        // 515/restartRequired may be part of normal pairing: wait for saved credentials,
        // reload them from disk, then start a fresh socket.
        await saveQueue
        reconnects += 1
        if (reconnects > MAX_RECONNECTS) {
          console.error('تجاوزنا عدد محاولات إعادة الاتصال. أعد تشغيل الأداة لاحقًا، ولا تحذف wa-auth إلا إذا طُلب منك ذلك.')
          await shutdown(1)
          return
        }

        const { state: latestState } = await useMultiFileAuthState(AUTH_DIR)
        if (!latestState.creds.registered) pairingRequested = false
        console.log(`إعادة الاتصال تلقائيًا (${reconnects}/${MAX_RECONNECTS})…`)
        setTimeout(() => connect().catch(async (error) => {
          console.error('تعذر إعادة الاتصال:', error.message)
          await shutdown(1)
        }), 1500)
      }
    })
  }

  process.on('SIGINT', () => {
    console.log('\nإيقاف الأداة…')
    shutdown(0)
  })

  await connect()
}

main().catch((error) => {
  console.error(`خطأ: ${error.message}`)
  rl.close()
  process.exit(1)
})
