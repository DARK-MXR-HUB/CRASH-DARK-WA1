import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys'
import readline from 'node:readline'

const DEFAULT_CHANNEL_URL = 'https://whatsapp.com/channel/0029Vb9TO6G2ER6ju5pmgQ3Z'
const AUTH_DIR = './wa-auth'

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const ask = (prompt) => new Promise((resolve) => rl.question(prompt, resolve))

function extractInviteCode(input) {
  const value = input.trim()
  const pathMatch = value.match(/\/channel\/([A-Za-z0-9]+)/i)
  const code = pathMatch ? pathMatch[1] : value
  if (!/^[A-Za-z0-9]{10,64}$/.test(code)) {
    throw new Error('لم أتعرف على رمز الدعوة. ألصق رابطًا بصيغة https://whatsapp.com/channel/… أو الرمز نفسه.')
  }
  return code
}

function normalizePhone(input) {
  const digits = input.replace(/\D/g, '')
  if (digits.length < 8 || digits.length > 15) {
    throw new Error('أدخل رقم واتساب مع مفتاح الدولة، أرقام فقط، مثل 201012345678.')
  }
  return digits
}

async function main() {
  console.log('\nاستخراج معرّف قناة واتساب (JID) — قراءة بيانات فقط، دون إرسال رسائل.\n')
  const rawLink = await ask(`رابط القناة [اضغط Enter لاستخدام قناة طمأنينة]:\n> `)
  const inviteCode = extractInviteCode(rawLink || DEFAULT_CHANNEL_URL)

  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
  const sock = makeWASocket({ auth: state })
  let pairingRequested = false
  let lookupStarted = false
  let shuttingDown = false

  const shutdown = (exitCode = 0) => {
    if (shuttingDown) return
    shuttingDown = true
    rl.close()
    try { sock.end(undefined) } catch {}
    setTimeout(() => process.exit(exitCode), 300)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async ({ connection, qr, lastDisconnect }) => {
    if (qr && !sock.authState.creds.registered && !pairingRequested) {
      pairingRequested = true
      try {
        const phoneText = await ask('\nأدخل رقم واتساب مع مفتاح الدولة (أرقام فقط، دون +):\n> ')
        const phone = normalizePhone(phoneText)
        const code = await sock.requestPairingCode(phone)
        console.log(`\nرمز الاقتران: ${code}`)
        console.log('أدخله في واتساب على الهاتف: الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف.')
        console.log('لا ترسل الرمز إلى أي شخص. انتظر حتى يكتمل الربط…\n')
      } catch (error) {
        console.error(`\nتعذر طلب رمز الاقتران: ${error.message}`)
        shutdown(1)
      }
    }

    if (connection === 'open' && !lookupStarted) {
      lookupStarted = true
      console.log('تم الاتصال. جارٍ الاستعلام عن معرّف القناة…')
      try {
        const metadata = await sock.newsletterMetadata('invite', inviteCode)
        if (!metadata?.id) throw new Error('لم يُرجع واتساب معرّفًا للقناة. تحقق من رابط الدعوة وحاول مجددًا.')
        console.log('\nالقناة:', metadata.name || '(لم يُرجع اسم القناة)')
        console.log('المعرّف:', metadata.id)
        console.log('\nانتهى الاستخراج. أُغلِق اتصال السكربت، لكن قد يظل الجهاز مرتبطًا بحسابك.')
        console.log('لإلغاء الربط نهائيًا: واتساب ← الأجهزة المرتبطة ← اختر الجهاز ← تسجيل الخروج.\n')
        shutdown(0)
      } catch (error) {
        console.error(`\nفشل جلب بيانات القناة: ${error.message}`)
        console.error('تأكد أن الرابط صحيح وأنه رابط قناة عامة، ثم جرّب مرة أخرى.\n')
        shutdown(1)
      }
    }

    if (connection === 'close' && !lookupStarted) {
      const statusCode = lastDisconnect?.error?.output?.statusCode
      if (statusCode === DisconnectReason.loggedOut) {
        console.error('\nانتهت جلسة واتساب أو تم تسجيل خروجها. احذف مجلد wa-auth ثم أعد تشغيل الأداة لربط الحساب من جديد.\n')
        shutdown(1)
      }
    }
  })
}

main().catch((error) => {
  console.error(`خطأ: ${error.message}`)
  rl.close()
  process.exit(1)
})
