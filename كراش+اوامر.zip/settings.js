const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "9164356544:AAEnTlWTNBi3jKAothJkRAxU99ib3R5UNIs" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "Crach_v1_dark" //your bot name
global.OWNER_NAME = "https://t.me/UF_VJ" //your name with sign @
global.OWNER = ["https://t.me/UF_VJ"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["7790083447"] //developer telegram id to operate addprem delprem and listprem
global.ppp = 'https://files.catbox.moe/8c1rds.jpg' //your bot pp
global.pp = 'https://files.catbox.moe/mqqwrt.jpg'

//approval
global.GROUP_ID = -1003812508070; // Replace with your group ID
global.CHANNEL_ID =  -1003974174648; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/super_spiders"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/MARO_EL_BRAZEILI"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://whatsapp.com/channel/0029Vb9TO6G2ER6ju5pmgQ3Z"; // Replace with your group link
global.YOUTUBE_LINK = "https://youtube.com/@mohamed-reda-2027?si=WPdLpbjAc3UmWG4-"; // Replace with your youtube link
//global.INSTAGRAM_LINK = ""; // Replace with your ig link

global.owner = global.owner = ['201211264876'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright(`Update ${__filename}`))
  delete require.cache[file]
  require(file)
})
